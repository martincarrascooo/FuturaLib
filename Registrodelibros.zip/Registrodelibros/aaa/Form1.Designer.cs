﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            registerbook = new Button();
            comboBox1 = new ComboBox();
            label1 = new Label();
            Ingresartitulo = new Label();
            label3 = new Label();
            error1 = new Label();
            Ingresarautor = new Label();
            Ingresaraño = new Label();
            ingresargenero = new Label();
            listBox4 = new ListBox();
            stock = new Label();
            error2 = new Label();
            error3 = new Label();
            error4 = new Label();
            label12 = new Label();
            comboBox2 = new ComboBox();
            dateTimePicker1 = new DateTimePicker();
            BarraBusquedad = new TextBox();
            textBox3 = new TextBox();
            text = new TextBox();
            pictureBox1 = new PictureBox();
            error = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // registerbook
            // 
            registerbook.ForeColor = Color.FromArgb(11, 168, 213);
            registerbook.Location = new Point(456, 355);
            registerbook.Margin = new Padding(4, 3, 4, 3);
            registerbook.Name = "registerbook";
            registerbook.Size = new Size(118, 23);
            registerbook.TabIndex = 1;
            registerbook.Text = "Registrar Libro";
            registerbook.UseVisualStyleBackColor = true;
            registerbook.Click += button1_Click;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.WhiteSmoke;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(15, 41);
            comboBox1.Margin = new Padding(4, 3, 4, 3);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(140, 21);
            comboBox1.TabIndex = 4;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.FromArgb(11, 168, 213);
            label1.Location = new Point(258, 26);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(114, 13);
            label1.TabIndex = 5;
            label1.Text = "Barra de busqueda";
            label1.Click += label1_Click;
            // 
            // Ingresartitulo
            // 
            Ingresartitulo.AutoSize = true;
            Ingresartitulo.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            Ingresartitulo.ForeColor = Color.FromArgb(11, 168, 213);
            Ingresartitulo.Location = new Point(258, 88);
            Ingresartitulo.Margin = new Padding(4, 0, 4, 0);
            Ingresartitulo.Name = "Ingresartitulo";
            Ingresartitulo.Size = new Size(89, 13);
            Ingresartitulo.TabIndex = 6;
            Ingresartitulo.Text = "Ingresar Titulo";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.FromArgb(11, 168, 213);
            label3.Location = new Point(16, 25);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(60, 13);
            label3.TabIndex = 7;
            label3.Text = "Opciones";
            // 
            // error1
            // 
            error1.AutoSize = true;
            error1.ForeColor = Color.FromArgb(250, 165, 0);
            error1.Location = new Point(582, 104);
            error1.Margin = new Padding(4, 0, 4, 0);
            error1.Name = "error1";
            error1.Size = new Size(59, 13);
            error1.TabIndex = 8;
            error1.Text = "tirar error";
            // 
            // Ingresarautor
            // 
            Ingresarautor.AutoSize = true;
            Ingresarautor.ForeColor = Color.FromArgb(11, 168, 213);
            Ingresarautor.Location = new Point(258, 152);
            Ingresarautor.Margin = new Padding(4, 0, 4, 0);
            Ingresarautor.Name = "Ingresarautor";
            Ingresarautor.Size = new Size(87, 13);
            Ingresarautor.TabIndex = 10;
            Ingresarautor.Text = "Ingresar Autor";
            // 
            // Ingresaraño
            // 
            Ingresaraño.AutoSize = true;
            Ingresaraño.BackColor = Color.Transparent;
            Ingresaraño.ForeColor = Color.FromArgb(11, 168, 213);
            Ingresaraño.Location = new Point(258, 208);
            Ingresaraño.Margin = new Padding(4, 0, 4, 0);
            Ingresaraño.Name = "Ingresaraño";
            Ingresaraño.Size = new Size(79, 13);
            Ingresaraño.TabIndex = 12;
            Ingresaraño.Text = "Ingresar Año";
            // 
            // ingresargenero
            // 
            ingresargenero.AutoSize = true;
            ingresargenero.ForeColor = Color.FromArgb(11, 168, 213);
            ingresargenero.Location = new Point(258, 268);
            ingresargenero.Margin = new Padding(4, 0, 4, 0);
            ingresargenero.Name = "ingresargenero";
            ingresargenero.Size = new Size(98, 13);
            ingresargenero.TabIndex = 14;
            ingresargenero.Text = "Ingresar Genero";
            ingresargenero.Click += label7_Click;
            // 
            // listBox4
            // 
            listBox4.FormattingEnabled = true;
            listBox4.Location = new Point(265, 348);
            listBox4.Margin = new Padding(4, 3, 4, 3);
            listBox4.Name = "listBox4";
            listBox4.Size = new Size(65, 30);
            listBox4.TabIndex = 15;
            listBox4.SelectedIndexChanged += listBox4_SelectedIndexChanged;
            // 
            // stock
            // 
            stock.AutoSize = true;
            stock.ForeColor = Color.FromArgb(11, 168, 213);
            stock.Location = new Point(262, 332);
            stock.Margin = new Padding(4, 0, 4, 0);
            stock.Name = "stock";
            stock.Size = new Size(40, 13);
            stock.TabIndex = 16;
            stock.Text = "Stock";
            // 
            // error2
            // 
            error2.AutoSize = true;
            error2.ForeColor = Color.FromArgb(250, 165, 0);
            error2.Location = new Point(582, 168);
            error2.Margin = new Padding(4, 0, 4, 0);
            error2.Name = "error2";
            error2.Size = new Size(59, 13);
            error2.TabIndex = 17;
            error2.Text = "tirar error";
            // 
            // error3
            // 
            error3.AutoSize = true;
            error3.ForeColor = Color.FromArgb(250, 165, 0);
            error3.Location = new Point(582, 238);
            error3.Margin = new Padding(4, 0, 4, 0);
            error3.Name = "error3";
            error3.Size = new Size(59, 13);
            error3.TabIndex = 18;
            error3.Text = "tirar error";
            // 
            // error4
            // 
            error4.AutoSize = true;
            error4.ForeColor = Color.FromArgb(250, 165, 0);
            error4.Location = new Point(463, 291);
            error4.Margin = new Padding(4, 0, 4, 0);
            error4.Name = "error4";
            error4.Size = new Size(59, 13);
            error4.TabIndex = 19;
            error4.Text = "tirar error";
            error4.Click += label11_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(582, 379);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(0, 13);
            label12.TabIndex = 20;
            label12.Click += label12_Click;
            // 
            // comboBox2
            // 
            comboBox2.BackColor = Color.WhiteSmoke;
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Terror", "Suspenso", "Accion", "Medieval ", "Romance", "Historico" });
            comboBox2.Location = new Point(261, 291);
            comboBox2.Margin = new Padding(4, 3, 4, 3);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(175, 21);
            comboBox2.TabIndex = 21;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.CalendarMonthBackground = Color.WhiteSmoke;
            dateTimePicker1.Location = new Point(261, 231);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(313, 20);
            dateTimePicker1.TabIndex = 22;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // BarraBusquedad
            // 
            BarraBusquedad.BackColor = Color.WhiteSmoke;
            BarraBusquedad.Location = new Point(261, 42);
            BarraBusquedad.Name = "BarraBusquedad";
            BarraBusquedad.Size = new Size(313, 20);
            BarraBusquedad.TabIndex = 23;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.WhiteSmoke;
            textBox3.Location = new Point(261, 168);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(313, 20);
            textBox3.TabIndex = 24;
            // 
            // text
            // 
            text.BackColor = Color.WhiteSmoke;
            text.Location = new Point(261, 104);
            text.Name = "text";
            text.Size = new Size(313, 20);
            text.TabIndex = 25;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Registrodelibros.Properties.Resources.icono_;
            pictureBox1.Location = new Point(294, 42);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(266, 266);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 26;
            pictureBox1.TabStop = false;
            // 
            // error
            // 
            error.AutoSize = true;
            error.ForeColor = Color.FromArgb(250, 165, 0);
            error.Location = new Point(582, 41);
            error.Margin = new Padding(4, 0, 4, 0);
            error.Name = "error";
            error.Size = new Size(59, 13);
            error.TabIndex = 27;
            error.Text = "tirar error";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 13F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(933, 450);
            Controls.Add(error);
            Controls.Add(text);
            Controls.Add(textBox3);
            Controls.Add(BarraBusquedad);
            Controls.Add(dateTimePicker1);
            Controls.Add(comboBox2);
            Controls.Add(label12);
            Controls.Add(error4);
            Controls.Add(error3);
            Controls.Add(error2);
            Controls.Add(stock);
            Controls.Add(listBox4);
            Controls.Add(ingresargenero);
            Controls.Add(Ingresaraño);
            Controls.Add(Ingresarautor);
            Controls.Add(error1);
            Controls.Add(label3);
            Controls.Add(Ingresartitulo);
            Controls.Add(label1);
            Controls.Add(comboBox1);
            Controls.Add(registerbook);
            Controls.Add(pictureBox1);
            Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 3, 4, 3);
            Name = "Form1";
            Text = "Futuralib";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.Button registerbook;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Ingresartitulo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label error1;
        private System.Windows.Forms.Label Ingresarautor;
        private System.Windows.Forms.Label Ingresaraño;
        private System.Windows.Forms.Label ingresargenero;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.Label stock;
        private System.Windows.Forms.Label error2;
        private System.Windows.Forms.Label error3;
        private System.Windows.Forms.Label error4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox BarraBusquedad;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox text;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Label error;
    }
}

